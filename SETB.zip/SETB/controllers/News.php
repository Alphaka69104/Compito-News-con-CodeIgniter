<?php
class News extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('News_model');
    }

    // mostra tutte le news
    public function index() {
        $data['news'] = $this->News_model->get_news();
        $this->load->view('news_list', $data);
    }

    // form inserimento
    public function create() {
        $this->load->view('news_create');
    }

    // salva news
    public function store() {
        $this->News_model->insert_news(
            $this->input->post('title'),
            $this->input->post('text')
        );
        $this->load->view('success');
    }
}
?>