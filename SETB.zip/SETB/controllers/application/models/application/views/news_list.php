<h1>Lista News</h1>

<a href="create">Aggiungi News</a>

<?php foreach ($news as $n): ?>

<h2><?php echo $n->title; ?></h2>
<p><?php echo $n->text; ?></p>
<hr>

<?php endforeach; ?>