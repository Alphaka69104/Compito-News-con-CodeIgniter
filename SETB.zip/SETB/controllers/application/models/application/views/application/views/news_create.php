<h1>Inserisci News</h1>

<form method="post" action="store">

Titolo<br>
<input type="text" name="title"><br><br>

Testo<br>
<textarea name="text"></textarea><br><br>

<button type="submit">Salva</button>

</form>