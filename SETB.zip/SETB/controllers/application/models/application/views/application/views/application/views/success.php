<h2>News inserita!</h2>

<a href="index">Torna alla lista</a>