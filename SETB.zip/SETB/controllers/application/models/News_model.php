<?php
class News_model extends CI_Model {

    public function get_news() {
        $query = $this->db->get('news');
        return $query->result();
    }

    public function insert_news($title, $text) {
        $data = array(
            'title' => $title,
            'text' => $text
        );

        $this->db->insert('news', $data);
    }
}
?>